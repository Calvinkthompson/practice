module.exports = (temp, product) => {
    let output = temp.replace(/{%PRODUCTNAME%}/g, product.productName);
    output = output.replace(/{%PRICEOLD%}/g, product.productOldPrice);
    output = output.replace(/{%PRICENEW%}/g, product.productNewPrice);
    output = output.replace(/{%PRODUCTIMAGE%}/g, product.productImage);

    return output;
};

