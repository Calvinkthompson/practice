const fs = require('fs');
const http = require('http');
const replaceTemplate = require('/Users/jacobblack/Desktop/LoveNest-Node/replaceTemplate.js');
const replaceLargeTemplate = require('/Users/jacobblack/Desktop/LoveNest-Node/replaceLargeTemplate.js');



// Read Pages
const mainPage = fs.readFileSync('/Users/jacobblack/Desktop/LoveNest-Node/index.html', 'utf-8');
const productCard = fs.readFileSync('/Users/jacobblack/Desktop/LoveNest-Node/product.html', 'utf-8');
const data = fs.readFileSync('/Users/jacobblack/Desktop/LoveNest-Node/productData.json', 'utf-8');
const dataObj = JSON.parse(data);

//Read Pages Large
const largeProductCard = fs.readFileSync('/Users/jacobblack/Desktop/LoveNest-Node/largeProduct.html', 'utf-8');
const largeData = fs.readFileSync('/Users/jacobblack/Desktop/LoveNest-Node/largeProduct.json', 'utf-8');
const largeDataObj = JSON.parse(largeData);

// Server
const server = http.createServer((req, res) => {
    res.writeHead(200, {'Content-type': 'text/html'});

    // Create Product Cards
    const cardComplete = dataObj.map(el => replaceTemplate(productCard, el)).join('');
    const largeCardComplete = largeDataObj.map(el => replaceLargeTemplate(largeProductCard, el)).join('');

    // Assuming mainPage has placeholders for both card types
    let output = mainPage.replace('{%PRODUCT_CARDS%}', cardComplete);
    output = output.replace('{%LARGE_PRODUCT_CARDS%}', largeCardComplete);     

    res.end(output);
});



server.listen(5500, '127.0.0.1', () => {
    console.log('Listening to requests on port 5500');
});
