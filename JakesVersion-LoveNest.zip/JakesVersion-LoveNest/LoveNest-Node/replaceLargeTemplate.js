module.exports = (temp, largeProduct) => {
    let largeOutput = temp.replace(/{%LARGEPRODUCTNAME%}/g, largeProduct.productName);
    largeOutput = largeOutput.replace(/{%LARGEPRICENEW%}/g, largeProduct.productNewPrice);
    largeOutput = largeOutput.replace(/{%LARGEPRODUCTIMAGE%}/g, largeProduct.productImage);

    return largeOutput;
};

